package com.jenkins.AllDB_Backup;
import hudson.Launcher;
import hudson.Extension;
import hudson.FilePath;
import hudson.util.FormValidation;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.Builder;
import hudson.tasks.BuildStepDescriptor;
import jenkins.tasks.SimpleBuildStep;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.QueryParameter;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import java.io.IOException;

public class BackupAllDB extends Builder implements SimpleBuildStep {

	private final String Mysql_Path;
    private final String BackupFile;
	private final String Username;
	private final String Password;
  
    @DataBoundConstructor
    public BackupAllDB(String Mysql_Path, String BackupFile, String Username,String Password) {
        this.Mysql_Path = Mysql_Path;
        this.BackupFile = BackupFile;
		this.Username = Username;
		this.Password = Password;
    }
    public String getMysql_Path() {
        return Mysql_Path;
    }
       public String getBackupFile() {
        return BackupFile;
    }
	public String getUsername() {
        return Username;
    }
	public String getPassword() {
        return Password;
    }
   
	public void perform(Run<?, ?> build, FilePath workspace, Launcher launcher, TaskListener listener)
			throws InterruptedException, IOException{
       DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		String backupName = BackupFile + "-" + date1 + ".sql";
		boolean flag=false;
		String command = Mysql_Path + "\\mysqldump.exe --user=" + Username + " --password=" + Password
				+ " --all-databases" + " -r " + backupName;
		try {
			Process runtimeProcess = Runtime.getRuntime().exec(command);
			int processComplete = runtimeProcess.waitFor();

			if (processComplete == 0) {
			listener.getLogger().println("backup: Backup Successfull !");
				flag= true;
				
			} else 
			{
				listener.getLogger().println("backup: Backup Failure !");
				flag=false;
			}

		} catch (IOException ioe) {
		listener.getLogger().println("Exception IO");
			ioe.printStackTrace();
		} catch (Exception e) {
		listener.getLogger().println("Exception");
			e.printStackTrace();
		}
		if(flag==true)
		{
			listener.getLogger().println("Successfull");
		}
		else
			
			listener.getLogger().println("Failed");
	}
		
		
    @Override
    public DescriptorImpl getDescriptor() {
        return (DescriptorImpl)super.getDescriptor();
   }

  @Extension // This indicates to Jenkins that this is an implementation of an extension point.
    public static final class DescriptorImpl extends BuildStepDescriptor<Builder> {
    
         public DescriptorImpl() {
            load();
        }
   
        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            // Indicates that this builder can be used with all kinds of project types 
            return true;
        }

            public String getDisplayName() {
            return "MySqlAllDB_Backup";
        }

    }




}

