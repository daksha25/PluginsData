package com.jenkins_2.Restore;
import hudson.Launcher;
import hudson.Extension;
import hudson.FilePath;
import hudson.util.FormValidation;
import hudson.model.AbstractProject;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.Builder;
import hudson.tasks.BuildStepDescriptor;
import jenkins.tasks.SimpleBuildStep;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.QueryParameter;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import java.io.IOException;

public class RestoreDB extends Builder implements SimpleBuildStep {

	private final String Mysql_Path;
    private final String BackupFile;
	private final String Username;
	private final String Password;
	private final String DatabaseName;
  
    @DataBoundConstructor
    public RestoreDB(String Mysql_Path, String BackupFile, String Username,String Password,String DatabaseName) {
        this.Mysql_Path = Mysql_Path;
        this.BackupFile = BackupFile;
		this.Username = Username;
		this.Password = Password;
		this.DatabaseName=DatabaseName;
    }
    public String getMysql_Path() {
        return Mysql_Path;
    }
       public String getBackupFile() {
        return BackupFile;
    }
	public String getUsername() {
        return Username;
    }
	public String getPassword() {
        return Password;
    }
	public String getDatabaseName() {
        return DatabaseName;
    }
       public void perform(Run<?,?> build, FilePath workspace, Launcher launcher, TaskListener listener){
       String[] executeCmd = new String[]{Mysql_Path + "\\mysql.exe", DatabaseName, "-u" + Username, "-p" + Password, "-e", " source " + BackupFile};
try {
	    /*processComplete=0 if correctly executed, will contain other values if not*/
	    Process runtimeProcess = Runtime.getRuntime().exec(executeCmd);
	    int processComplete = runtimeProcess.waitFor();

	    /* processComplete=0 if correctly executed, will contain other values if not*/
	    if (processComplete == 0) {
	      listener.getLogger().println( "Successfully restored to SQL : ");
	    } else {
	      listener.getLogger().println( "Error at restoring");
	    }

		} catch (IOException ioe) {
		listener.getLogger().println("Exception IO");
			ioe.printStackTrace();
		} catch (Exception e) {
	listener.getLogger().println("Exception");
			e.printStackTrace();
		}
	   }
	
		
		
    @Override
    public DescriptorImpl getDescriptor() {
        return (DescriptorImpl)super.getDescriptor();
   }

  @Extension // This indicates to Jenkins that this is an implementation of an extension point.
    public static final class DescriptorImpl extends BuildStepDescriptor<Builder> {
    
         public DescriptorImpl() {
            load();
        }
   
        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            // Indicates that this builder can be used with all kinds of project types 
            return true;
        }

            public String getDisplayName() {
            return "MySql_RestoreDatabase";
        }

    }
}

