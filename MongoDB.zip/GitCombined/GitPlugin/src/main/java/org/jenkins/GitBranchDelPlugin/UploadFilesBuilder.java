package org.jenkins.GitBranchDelPlugin;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;

import hudson.Extension;
import hudson.FilePath;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Builder;
import hudson.util.FormValidation;
import net.sf.json.JSONObject;

public class UploadFilesBuilder extends Builder {

  
	 private String repoName;
		 private String repoPath;
		 private String folderPath;		
		 private String authFileLocation;
	
    // Fields in config.jelly must match the parameter names in the "DataBoundConstructor"
    @DataBoundConstructor
    public UploadFilesBuilder(String repoName,String repoPath,String folderPath,String authFileLocation) {
        this.repoName = repoName;
        this.repoPath = repoPath;
        this.folderPath = folderPath;     
        this.authFileLocation = authFileLocation;
    }
	

    public String getrepoName() {
        return repoName;
    }
	 public String getrepoPath() {
        return repoPath;
    }
	 public String getfolderPath() {
        return folderPath;
    }
	 
	 public String getauthFileLocation() {
        return authFileLocation;
    }

	 public boolean perform(AbstractBuild<?, ?> build,Launcher launcher, BuildListener listener) throws FileNotFoundException, IOException  {        // This is where you 'build' the project.
        // Since this is a dummy, we just say 'hello world' and call that a build.
		
			this.repoName=repoName;
			this.repoPath = repoPath;
	        this.folderPath = folderPath;
	         this.authFileLocation = authFileLocation;
	        listener.getLogger().println(repoName);
	        listener.getLogger().println(repoPath);
	        listener.getLogger().println(folderPath);
	      
	        listener.getLogger().println(authFileLocation);	    
	        boolean status = false;
	           CommonUtilsGit git = new CommonUtilsGit();       
	        		
			try {
				status = git.fileUpload(repoName, repoPath, folderPath, authFileLocation, listener);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				
	           listener.getLogger().println(status);
			return status;
			
    }

    // Overridden for better type safety.
    // If your plugin doesn't really define any property on Descriptor,
    // you don't have to do this.
    @Override
    public DescriptorImpl getDescriptor() {
        return (DescriptorImpl)super.getDescriptor();
    }

    @Extension // This indicates to Jenkins that this is an implementation of an extension point.
    public static final class DescriptorImpl extends BuildStepDescriptor<Builder> {
      
     

        public DescriptorImpl() {
            load();
        }

     

        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            // Indicates that this builder can be used with all kinds of project types 
            return true;
        }

        /**
         * This human readable name is used in the configuration screen.
         */
        public String getDisplayName() {
            return "Cloudset Git Upload Files";
        }

    
    }
}

