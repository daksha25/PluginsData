package org.jenkins.GitBranchDelPlugin;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.StaplerRequest;

import hudson.Extension;
import hudson.FilePath;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.BuildListener;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.Builder;
import hudson.util.FormValidation;
import net.sf.json.JSONObject;

public class DownloadFolderBuilder extends Builder {

  
	 private String localUrl;
		 private String repoPath;
		 private String folderName;
		 private String authFileLocation;
	

    // Fields in config.jelly must match the parameter names in the "DataBoundConstructor"
    @DataBoundConstructor
    public DownloadFolderBuilder(String localUrl,String repoPath,String folderName,String authFileLocation) {
        this.localUrl = localUrl;       
        this.repoPath = repoPath;
        this.folderName = folderName;
        this.authFileLocation = authFileLocation;
    }
	

    public String getlocalUrl() {
        return localUrl;
    }
	 
	 public String getrepoPath() {
        return repoPath;
    }
	 public String getfolderName() {
        return folderName;
    }
	 public String getauthFileLocation() {
        return authFileLocation;
    }

	 public boolean perform(AbstractBuild<?, ?> build,Launcher launcher, BuildListener listener) throws FileNotFoundException, IOException  {        // This is where you 'build' the project.
       
		
			this.localUrl=localUrl;
			
	        this.repoPath = repoPath;
	        this.folderName = folderName;
	        this.authFileLocation = authFileLocation;
	        listener.getLogger().println(localUrl);	     
	        listener.getLogger().println(repoPath);
	        listener.getLogger().println(folderName);
	        listener.getLogger().println(authFileLocation);	  
	        boolean status = false;
	           CommonUtilsGit git = new CommonUtilsGit();         
	        					
					try {
						status = git.downloadFolder(localUrl, repoPath, folderName, authFileLocation, listener);
						
					} catch (KeyManagementException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
							
						
					
				
	           listener.getLogger().println(status);
			return status;
		
    }

    // Overridden for better type safety.
    // If your plugin doesn't really define any property on Descriptor,
    // you don't have to do this.
    @Override
    public DescriptorImpl getDescriptor() {
        return (DescriptorImpl)super.getDescriptor();
    }

    @Extension // This indicates to Jenkins that this is an implementation of an extension point.
    public static final class DescriptorImpl extends BuildStepDescriptor<Builder> {
      
        private boolean useFrench;

        public DescriptorImpl() {
            load();
        }

     

        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            // Indicates that this builder can be used with all kinds of project types 
            return true;
        }

        /**
         * This human readable name is used in the configuration screen.
         */
        public String getDisplayName() {
            return "Cloudset Git Download Folder";
        }

    
    }
}

