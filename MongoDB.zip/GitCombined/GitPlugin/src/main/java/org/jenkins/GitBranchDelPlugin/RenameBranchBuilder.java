package org.jenkins.GitBranchDelPlugin;
import hudson.Launcher;
import hudson.Extension;
import hudson.model.Build;
import hudson.model.BuildListener;
import hudson.model.Descriptor.FormException;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.Builder;
import hudson.util.FormValidation;
import hudson.tasks.BuildStepDescriptor;

import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.Descriptor;
import javax.servlet.ServletException;

import net.sf.json.JSONObject;

public class RenameBranchBuilder extends Builder {
	String repoPath = null;
	String oldBranchName = null;
	String newBranchName = null;
	String authFileLocation = null;
	String commitMsg = "Creating a new branch in github";
  
  

    public String getRepoPath() {
		return repoPath;
	}

	public void setRepoPath(String repoPath) {
		this.repoPath = repoPath;
	}

	public String getOldBranchName() {
		return oldBranchName;
	}

	public void setOldBranchName(String oldBranchName) {
		this.oldBranchName = oldBranchName;
	}

	public String getNewBranchName() {
		return newBranchName;
	}

	public void setNewBranchName(String newBranchName) {
		this.newBranchName = newBranchName;
	}

	public String getAuthFileLocation() {
		return authFileLocation;
	}

	public void setAuthFileLocation(String authFileLocation) {
		this.authFileLocation = authFileLocation;
	}

	// Fields in config.jelly must match the parameter names in the "DataBoundConstructor"
	@DataBoundConstructor
    public  RenameBranchBuilder(String repoPath, String oldBranchName,String newBranchName,String authFileLocation) {
		this.repoPath=repoPath;
		this.oldBranchName=oldBranchName;
		this.newBranchName=newBranchName;
		this.authFileLocation= authFileLocation;
		
	}

	@Override
	public boolean perform(AbstractBuild<?, ?> build,Launcher launcher, BuildListener listener) throws IOException, InterruptedException {
		this.repoPath=repoPath;
		this.oldBranchName=oldBranchName;
		this.newBranchName=newBranchName;
		this.authFileLocation= authFileLocation;
		CommonUtilsGit git=new CommonUtilsGit();
		boolean value=false;
		String patternToMatch = "[\\\\!\"#$%&()*+,./:;<=>?@\\[\\]^_{|}~]+\\s*";
		Pattern p = Pattern.compile(patternToMatch);
		Matcher m = p.matcher(newBranchName);
		boolean characterFound = m.find();
		
		if(characterFound==false)
		{
			value=git.renameBranch(repoPath, oldBranchName, newBranchName, authFileLocation, commitMsg);
			listener.getLogger().println(value);		
	    	return value;
		}
		else
			listener.getLogger().println("Provide the branch name without special characters.");
			return value;
		
		   
	}
	
	
	
		@Override
	    public DescriptorImpl getDescriptor() {
	        return (DescriptorImpl)super.getDescriptor();
	  }
		
    @Extension 
    public static final class DescriptorImpl extends BuildStepDescriptor<Builder> {
        
        public DescriptorImpl() {
            load();
        }

        public boolean isApplicable(Class<? extends AbstractProject> aClass) {
            // Indicates that this builder can be used with all kinds of project types 
            return true;
        }

        /**
         * This human readable name is used in the configuration screen.
         */
        public String getDisplayName() {
            return "Cloudset GIT Rename Branch";
        }

		
            
    }
	
}


