package com.cognizant.Plot_Graph;

import hudson.Launcher;
import hudson.EnvVars;
import hudson.Launcher.ProcStarter;
import hudson.FilePath;
import hudson.model.AbstractBuild;
import hudson.model.BuildListener;
import hudson.util.ArgumentListBuilder;
import hudson.util.ChartUtil.NumberOnlyBuildLabel;

import hudson.util.DataSetBuilder;

import hudson.util.ShiftedCategoryAxis;

import java.awt.BasicStroke;
import java.awt.Color;
//import org.apache.http.HttpResponse;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;

//import org.apache.http.HttpResponse;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RectangleInsets;

import hudson.model.Computer;
import hudson.model.ListView.Listener;
import hudson.remoting.Channel;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.slaves.Channels;

import java.net.*;

/**
 * This class does the actual execution..
 * 
 */
public class GraphPoints {
	public static String getpath(AbstractBuild<?, ?> build, BuildListener listener, String filePath1, int buildno)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		File file = new File("D:\\FilePath.txt");

		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			// true = append file
			fw = new FileWriter(file);
			bw = new BufferedWriter(fw);

			bw.write(filePath1);

			System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
		}
		System.out.println("Filepath in graph point " + filePath1);
		buildChart(build, listener, filePath1, buildno);
		buildChartDelta(build, listener, file, buildno);
		return filePath1;
	}

	@SuppressWarnings("deprecation")

	public static JFreeChart buildChart(AbstractBuild<?, ?> build, BuildListener listener, String filePath1, int buildno)
			throws IOException, InterruptedException {
		
		JFreeChart lineChart = null;

		lineChart = ChartFactory.createLineChart(null, "Build Number", "Number of Severities",
				createDataset(filePath1, buildno), PlotOrientation.VERTICAL, true, true, false);
		lineChart.setBackgroundPaint(Color.white);
		CategoryPlot plot = lineChart.getCategoryPlot();
		plot.setBackgroundPaint(Color.WHITE);
		plot.setRangeGridlinePaint(Color.black);

		LineAndShapeRenderer r2 = (LineAndShapeRenderer) plot.getRenderer();

		r2.setSeriesPaint(0, Color.RED);
		r2.setSeriesPaint(1, Color.BLUE);
		r2.setSeriesPaint(2, Color.GREEN);
		r2.setSeriesPaint(3, Color.DARK_GRAY);
	
		r2.setSeriesStroke(0, new BasicStroke(2.0f));
		r2.setSeriesStroke(1, new BasicStroke(2.0f));
		r2.setSeriesStroke(2, new BasicStroke(2.0f));
		r2.setSeriesStroke(3, new BasicStroke(2.0f));

		
		plot.setInsets(new RectangleInsets(0, 0, 0, 5.0));

		return lineChart;
	}

	public static CategoryDataset createDataset(String filePath1, int buildno) throws IOException {
		// String FilePath1 =GraphBuilder
		// FILENAME="D://values.properties";
		BufferedReader br = null;
		FileReader fr = null;
		String FileP = null;
		DefaultCategoryDataset builder = new DefaultCategoryDataset();

		fr = new FileReader(filePath1);
		br = new BufferedReader(fr);

		br = new BufferedReader(new FileReader(filePath1));

		while ((FileP = br.readLine()) != null) {
			System.out.println("contents in file" + FileP);
		

		System.out.println("contents in file while passing to create chart 1 " + FileP);

		Properties props = new Properties();
		System.out.println("in createDataset: " + FileP);
		FileInputStream fis = new FileInputStream(filePath1);
		
		props.load(fis);
		Set<Object> keys = props.keySet();
		List listKeys = new ArrayList();
		listKeys.addAll(keys);
		Collections.sort(listKeys);
		int sizeOfLoop = keys.size();
		System.out.println("Size of loop: " + sizeOfLoop);
	//	DefaultCategoryDataset builder = new DefaultCategoryDataset();
		// DataSetBuilder builder = new DataSetBuilder();
		if (listKeys.size() >= buildno) {
			for (int i = (listKeys.size() - buildno); i > (listKeys.size()); i++) {
				String value = props.getProperty((String) listKeys.get(i)).trim();
				int key = Integer.parseInt((String) listKeys.get(i));
				String[] array = value.split("\\,");
				// System.out.println("Array is: "+array);
				for (int j = 0; j < 4; j++) {
					int high = Integer.parseInt(array[0].trim());
					int med = Integer.parseInt(array[1].trim());
					int low = Integer.parseInt(array[2].trim());
					int neg = Integer.parseInt(array[3].trim());
					builder.addValue(high, "High", "#" + key);
					// System.out.println("This: "+high+"High"+key);
					builder.addValue(med, "Medium", "#" + key);
					builder.addValue(low, "Low", "#" + key);
					builder.addValue(neg, "Negligible", "#" + key);
				}
				fis.close();

			}
		} else {
			for (int i = 0; i < sizeOfLoop; i++) {
				String value = props.getProperty((String) listKeys.get(i)).trim();
				System.out.println(value);
				int key = Integer.parseInt((String) listKeys.get(i));
				String[] array = value.split("\\,");
				System.out.println("Array is: " + array);
				for (int j = 0; j < 4; j++) {
					int high = Integer.parseInt(array[0].trim());
					int med = Integer.parseInt(array[1].trim());
					int low = Integer.parseInt(array[2].trim());
					int neg = Integer.parseInt(array[3].trim());
					builder.addValue(high, "High", "#" + key);
					// System.out.println("This: "+high+"High"+key);
					builder.addValue(med, "Medium", "#" + key);
					builder.addValue(low, "Low", "#" + key);
					builder.addValue(neg, "Negligible", "#" + key);
				}
				fis.close();

			}
		}
		}

		System.out.println("Inside datset");

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();
		
		return builder;

	
	}

	// second chart stacked graph
	public static JFreeChart buildChartDelta(AbstractBuild<?, ?> build, BuildListener listener, File file,
			int buildno) throws IOException, InterruptedException {
		JFreeChart lineChart = null;
		
		
		
		// System.out.println("FILE NAME IS "+GraphPoints.FILENAME);
		
		System.out.println("in buildChartDelta: " + file);
		lineChart = ChartFactory.createStackedBarChart(null, "Build Number", "Total Severity Count",
				createDataset1(file, buildno), PlotOrientation.VERTICAL, true, true, false);

		lineChart.setBackgroundPaint(Color.white);

		CategoryPlot plot = lineChart.getCategoryPlot();
		plot.setBackgroundPaint(Color.WHITE);
		plot.setOutlinePaint(null);
		// plot.setForegroundAlpha(0.8f);
		plot.setRangeGridlinesVisible(true);
		plot.setRangeGridlinePaint(Color.black);

		CategoryAxis domainAxis = new ShiftedCategoryAxis(null);
		// plot.setDomainAxis(domainAxis);
		// domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
		// domainAxis.setLowerMargin(0.0);
		// domainAxis.setUpperMargin(0.0);
		// domainAxis.setCategoryMargin(0.0);

		NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

		// crop extra space around the graph
		plot.setInsets(new RectangleInsets(0, 0, 0, 5.0));
		return lineChart;
	}

	public static CategoryDataset createDataset1(File file, int buildno) throws IOException {
		DefaultCategoryDataset builder = new DefaultCategoryDataset();
		// FILENAME="D://values.properties";
		BufferedReader br = null;
		FileReader fr = null;
		String FileP = null;
		//DefaultCategoryDataset builder = new DefaultCategoryDataset();

		fr = new FileReader(file);
		br = new BufferedReader(fr);

		br = new BufferedReader(new FileReader(file));

		while ((FileP = br.readLine()) != null) {
			System.out.println("contents in file" + FileP);
		

		System.out.println("contents in file while passing to create chart 1 " + FileP);
		Properties props = new Properties();
		System.out.println("in createDataset1: " + FileP);
		/*System.out.println("contents in file while passing to create chart 2 " + FileP);*/
		FileInputStream fis = new FileInputStream(FileP);
		props.load(fis);
		Set<Object> keys = props.keySet();
		List listKeys = new ArrayList();
		listKeys.addAll(keys);
		Collections.sort(listKeys);
		int sizeOfLoop = keys.size();
		System.out.println("Size of loop: " + sizeOfLoop);

		
		if (listKeys.size() >= buildno) {
			for (int i = (listKeys.size() - buildno); i > (listKeys.size()); i++) {
				String value = props.getProperty((String) listKeys.get(i)).trim();
				int key = Integer.parseInt((String) listKeys.get(i));
				String[] array = value.split("\\,");
				// System.out.println("Array is: "+array);
				// for(int j=0;j<array.length;j++){
				int total = Integer.parseInt(array[4].trim());
				builder.addValue(total, "Total Count", "#" + key);
				// }
				fis.close();

			}
		} else {
			for (int i = 0; i < sizeOfLoop; i++) {
				String value = props.getProperty((String) listKeys.get(i)).trim();
				System.out.println(value);
				int key = Integer.parseInt((String) listKeys.get(i));
				String[] array = value.split("\\,");
				System.out.println("Array is: " + array);
				// for(int j=0;j<array.length;j++){
				int total = Integer.parseInt(array[4].trim());
				builder.addValue(total, "Total Count", "#" + key);
				// }
				fis.close();

			}
		}
		}
		if (br != null)
			br.close();

		if (fr != null)
			fr.close();
		
		return builder;

		

	}
}
