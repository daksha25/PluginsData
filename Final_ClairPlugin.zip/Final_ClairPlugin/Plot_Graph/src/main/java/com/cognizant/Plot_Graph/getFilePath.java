/*package com.cognizant.Plot_Graph;

import java.io.IOException;

import hudson.EnvVars;
import hudson.model.AbstractBuild;
import hudson.model.BuildListener;

public class getFilePath {

	public static String filepath(AbstractBuild<?, ?> build, BuildListener listener) throws IOException, InterruptedException {
		
		// TODO Auto-generated method stub
		String jn=System.getenv("JOB_NAME");
		System.out.println("job name on getfilepath class "+jn);
		EnvVars env = build.getEnvironment(listener);
    	String jobname=env.get("JOB_NAME");
    	String workspace=env.get("WORKSPACE");
    	String FilePath1=workspace+"/"+jobname+"/"+"_SeverityCount.properties";
    	System.out.println("File path on getfilepath class "+FilePath1);
		return FilePath1;
		
	}
	

}
*/